$(document).ready(function() {
	/*//Skin
	 $('#css_skin').attr('href', 'css/skin_light.css');
	 //Color theme
	 $('#css_color').attr('href', 'css/colors/color_green.css');
	 //Layout
	 $('#css_layout').attr('href', 'css/layout/layout_background.css');
	 //Pattern type
	 $('#css_pattern').attr('href', 'css/patterns/lines1.css');*/
});
